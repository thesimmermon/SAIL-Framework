# SAIL AI-Friendly Schema Package

This package contains a draft AI-friendly schema and semantic codebook for SAIL `.sail` files.

## Core files

- `schema/sail.schema.json` — JSON Schema for validating the structure of SAIL model files.
- `schema/sail-codebook.json` — semantic map for numeric enum values and observed string values.
- `schema/sail-codebook.schema.json` — simple schema for the codebook itself.

## AI-agent templates

- `templates/01-agent-architecture-context.md`
- `templates/02-implement-feature-with-sail-guardrails.md`
- `templates/03-review-code-against-sail.md`
- `templates/04-propose-architecture-change.md`

## Tools

- `tools/validate-sail.py` — validates a `.sail` file against `sail.schema.json`.
- `tools/build-ai-context.py` — creates a derived AI-friendly context summary from a canonical `.sail` file.

## Examples

- `examples/validation-report.example.json`
- `examples/model-diff.example.json`
- `examples/GridGuard.ai-context.summary.json`

## Important model decision

The canonical `.sail` JSON does **not** need to change for AI-agent use.

AI agents should use:

1. the `.sail` file as the source of architecture truth,
2. `sail.schema.json` to understand and validate structure,
3. `sail-codebook.json` to interpret numeric enum values, and
4. the templates to enforce architecture guardrails during implementation or review.

## Validation limits

JSON Schema can validate object shape, required fields, primitive types, UUID format, colors, and known enum ranges.

It should not be the only validator for SAIL. A separate SAIL model validator should check cross-reference integrity, such as:

- every `SourceId` and `TargetId` exists in `Inventory.StructuralElements`,
- every `InterfaceId` exists in `Inventory.Interfaces`,
- every `InterfaceOperationId` exists in the referenced interface operation catalog,
- every diagram element ID points to a valid inventory item where appropriate,
- diagram type rules are enforced beyond basic JSON shape.

## v0.1.1 update

Added confirmed `DiagramElementEdge` mapping:

- `0=None`
- `1=Top`
- `2=Bottom`
- `3=Left`
- `4=Right`

`SourceEdge` and `TargetEdge` in `sail.schema.json` are now constrained to these values.
